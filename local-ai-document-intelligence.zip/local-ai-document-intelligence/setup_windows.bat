@echo off
setlocal
cd /d "%~dp0"

echo [1/4] Checking Python...
python --version >nul 2>&1
if errorlevel 1 (
  echo Python was not found. Install Python 3.11 or 3.12 and enable "Add Python to PATH".
  pause
  exit /b 1
)

echo [2/4] Creating virtual environment...
if not exist ".venv\Scripts\python.exe" python -m venv .venv
if errorlevel 1 goto :error

echo [3/4] Updating pip...
call .venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 goto :error

echo [4/4] Installing project requirements...
call .venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Full installation failed. Trying the lightweight TF-IDF version...
  call .venv\Scripts\python.exe -m pip install -r requirements-lite.txt
  if errorlevel 1 goto :error
)

echo.
echo Installation completed. Run run_app.bat to start the application.
pause
exit /b 0

:error
echo.
echo Installation failed. Review the error message above.
pause
exit /b 1
