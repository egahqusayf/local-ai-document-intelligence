@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. Run setup_windows.bat first.
  pause
  exit /b 1
)
echo.
echo ===============================================
echo Local AI Document Intelligence - Theme Launcher
echo ===============================================
echo [1] Dark theme
echo [2] Light theme
echo.
choice /c 12 /n /m "Choose theme [1/2]: "
if errorlevel 2 goto light
if errorlevel 1 goto dark

goto dark

:dark
call .venv\Scripts\python.exe -m streamlit run app.py --theme.base dark --theme.primaryColor "#D94855" --theme.backgroundColor "#14080B" --theme.secondaryBackgroundColor "#211014" --theme.textColor "#FFF6F7"
goto end

:light
call .venv\Scripts\python.exe -m streamlit run app.py --theme.base light --theme.primaryColor "#A11B27" --theme.backgroundColor "#FFF9F9" --theme.secondaryBackgroundColor "#FFF1F2" --theme.textColor "#3A0E13"
goto end

:end
