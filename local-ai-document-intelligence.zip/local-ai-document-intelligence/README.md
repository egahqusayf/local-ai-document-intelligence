# Local AI Document Intelligence

A Windows-friendly, local-first application for asking grounded questions across one or more PDF documents. The system retrieves relevant passages, generates an answer, and shows the original filename, page number, relevance score, and excerpt as evidence.

## Project preview

### Grounded question answering

![Grounded answer interface](docs/figures/ui_answer_mockup.png)

### Multi-PDF indexing

![Document indexing interface](docs/figures/ui_index_mockup.png)

### System architecture

![System architecture and data flow](docs/figures/architecture.png)

## Main features

- Upload and index multiple text-based PDF files.
- Page-aware PDF extraction with PyMuPDF.
- Overlapping chunks that retain filename and page metadata.
- Multilingual semantic retrieval using Sentence Transformers.
- Automatic TF-IDF fallback when the embedding model is unavailable.
- Extractive answering that works without an LLM.
- Optional private answer generation through a local Ollama model.
- Source viewer with relevance score, filename, page number, and excerpt.
- Conversation history and Markdown export.
- Bundled sample PDF and automated core tests.
- Windows setup scripts and both Light and Dark display modes.

## Why this project matters

The project is designed around traceability rather than answer generation alone. Every retrieved chunk belongs to one PDF page, so users can verify the evidence before trusting the result. The application also remains functional when semantic embeddings or Ollama are unavailable.

## Project structure

```text
local-ai-document-intelligence/
|-- app.py
|-- src/
|   |-- answer_engine.py
|   |-- exporter.py
|   |-- models.py
|   |-- ollama_client.py
|   |-- pdf_processor.py
|   `-- retriever.py
|-- sample_docs/
|-- tests/
|-- docs/
|-- .streamlit/
|   |-- config.toml
|   |-- config_light.toml
|   `-- config_dark.toml
|-- setup_windows.bat
|-- run_app.bat
|-- run_app_light.bat
|-- run_app_dark.bat
|-- run_tests.bat
|-- requirements.txt
`-- requirements-lite.txt
```

## Windows installation

### Automatic setup

1. Install **Python 3.11 or 3.12**.
2. Enable **Add Python to PATH** during installation.
3. Extract the project ZIP.
4. Double-click `setup_windows.bat`.
5. After setup finishes, double-click `run_app.bat`.
6. Select the preferred display mode.
7. Streamlit opens the application in the browser.

The setup script first attempts the full semantic-search installation. If it fails, it installs the lightweight TF-IDF profile.

### PowerShell setup

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

When PowerShell blocks virtual-environment activation:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## Optional Ollama setup

Extractive mode works without Ollama. For local generative answers:

```powershell
ollama pull llama3.2:3b
ollama list
ollama run llama3.2:3b
```

Select **Ollama** in the application and use the exact installed model name.

## How to use

1. Open **Index documents**.
2. Upload one or more PDFs, or use the bundled sample.
3. Select the retrieval engine and chunk settings.
4. Click **Build document index**.
5. Open **Ask documents**.
6. Enter a specific question.
7. Review the answer and expand **View retrieved sources**.
8. Export the conversation to Markdown when required.

## Retrieval modes

- **Auto:** tries semantic retrieval and falls back to TF-IDF.
- **Sentence Transformers:** multilingual meaning-based search.
- **TF-IDF:** lightweight keyword and phrase retrieval.

## Answer modes

- **Extractive:** selects high-scoring sentences from retrieved evidence.
- **Ollama:** sends grounded evidence to a local language model.

## Testing

```powershell
python -m unittest discover -s tests -v
```

The end-to-end test creates a PDF in memory and validates extraction, chunking, TF-IDF retrieval, answer generation, and the `[S1]` citation.

## Ollama timeout

The client uses separate connection and response timeouts:

```python
timeout=(10, read_timeout)
```

Increase the read timeout for CPU-only computers or reduce the model size and number of evidence sources.

## Limitations

- No OCR for image-only PDFs.
- The index is stored in memory and rebuilt after restart.
- Chunking is based on words and pages rather than document headings.
- No cross-encoder reranker or highlighted PDF viewer yet.
- Ollama responses are non-streaming.

## Roadmap

- OCR support
- Persistent vector storage
- Cross-encoder reranking
- Highlighted evidence in a PDF viewer
- Streaming local generation
- Metadata filters
- Retrieval evaluation dashboard
- Authentication and Docker packaging

## Technology stack

Python, Streamlit, PyMuPDF, Scikit-learn, NumPy, Sentence Transformers, Requests, and Ollama.

## Documentation

