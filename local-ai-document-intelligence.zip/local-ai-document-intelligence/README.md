# Local AI Document Intelligence

A Windows-friendly, local-first application for asking grounded questions across one or more PDF documents. The system retrieves relevant passages, generates an answer, and displays the original filename, page number, relevance score, and excerpt as verifiable evidence.

## Download and extract the project

Before installing or running the application, download and extract the project ZIP.

1. Download the latest ZIP package from the repository or GitHub Releases.
2. Right-click the ZIP file and select **Extract All**.
3. Open the extracted `local-ai-document-intelligence` folder.
4. Do not run the application directly from inside the ZIP archive.

The extracted folder should contain:

```text
local-ai-document-intelligence/
|-- app.py
|-- src/
|-- sample_docs/
|-- tests/
|-- docs/
|-- .streamlit/
|-- setup_windows.bat
|-- run_app.bat
|-- run_app_light.bat
|-- run_app_dark.bat
|-- run_tests.bat
|-- requirements.txt
`-- requirements-lite.txt
```

## Quick start for Windows

1. Install **Python 3.11 or 3.12**.
2. Enable **Add Python to PATH** during installation.
3. Extract the project ZIP.
4. Open the extracted project folder.
5. Double-click `setup_windows.bat`.
6. Wait until the virtual environment and dependencies are installed.
7. Double-click `run_app.bat`.
8. Select the preferred display mode.
9. Streamlit will open the application in your browser.

The setup script first attempts the complete semantic-search installation. If that fails, it automatically installs the lightweight TF-IDF profile.

## Project preview

### Grounded question answering

![Grounded answer interface](docs/figures/ui_answer_mockup.png)

### Multi-PDF indexing

![Document indexing interface](docs/figures/ui_index_mockup.png)

### System architecture

![System architecture and data flow](docs/figures/architecture.png)

## Main features

- Upload and index multiple text-based PDF files.
- Page-aware PDF extraction using PyMuPDF.
- Overlapping chunks that retain filename and page metadata.
- Multilingual semantic retrieval using Sentence Transformers.
- Automatic TF-IDF fallback when the embedding model is unavailable.
- Extractive answering that works without a language model.
- Optional private answer generation through a local Ollama model.
- Source viewer with relevance score, filename, page number, and excerpt.
- Conversation history and Markdown export.
- Bundled sample PDF and automated core tests.
- Windows setup and launch scripts.
- Light and Dark display modes.

## Why this project matters

This project is designed around traceability rather than answer generation alone. Every retrieved chunk remains associated with its original PDF file and page number, allowing users to inspect the supporting evidence before trusting an answer.

The application also remains functional when semantic embeddings or Ollama are unavailable. Users can continue using TF-IDF retrieval and Extractive answering on computers with limited resources.

## Project structure

```text
local-ai-document-intelligence/
|-- app.py
|-- src/
|   |-- answer_engine.py
|   |-- exporter.py
|   |-- models.py
|   |-- ollama_client.py
|   |-- pdf_processor.py
|   `-- retriever.py
|-- sample_docs/
|-- tests/
|-- docs/
|   |-- ARCHITECTURE.md
|   `-- figures/
|       |-- ui_answer_mockup.png
|       |-- ui_index_mockup.png
|       `-- architecture.png
|-- .streamlit/
|   |-- config.toml
|   |-- config_light.toml
|   `-- config_dark.toml
|-- setup_windows.bat
|-- run_app.bat
|-- run_app_light.bat
|-- run_app_dark.bat
|-- run_tests.bat
|-- requirements.txt
`-- requirements-lite.txt
```

## Windows installation

### Automatic setup

Make sure the project ZIP has already been extracted.

1. Open the extracted project folder.
2. Double-click `setup_windows.bat`.
3. Wait for the setup process to finish.
4. Double-click `run_app.bat`.
5. Choose the preferred display mode.
6. The application will open in the default browser.

The setup script:

- Checks whether Python is available.
- Creates a virtual environment in `.venv`.
- Upgrades `pip`.
- Installs dependencies from `requirements.txt`.
- Falls back to `requirements-lite.txt` if the complete installation fails.

### PowerShell setup

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If PowerShell blocks virtual-environment activation:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

### Lightweight installation

Use the lightweight dependency profile when the computer has limited memory, storage, or processing capability:

```powershell
pip install -r requirements-lite.txt
streamlit run app.py
```

The lightweight profile does not install Sentence Transformers. TF-IDF retrieval, Extractive answering, PDF upload, source viewing, and Markdown export remain available.

## Optional Ollama setup

Extractive mode works without Ollama. To enable local generative answers:

```powershell
ollama pull llama3.2:3b
ollama list
ollama run llama3.2:3b
```

Start the Ollama server when necessary:

```powershell
ollama serve
```

Inside the application:

1. Select **Ollama** as the answer mode.
2. Enter the exact installed model name.
3. Keep the default local URL: `http://localhost:11434`.

## How to use

1. Extract the project ZIP.
2. Install the project dependencies.
3. Start the application.
4. Open **Index documents**.
5. Upload one or more text-based PDF files, or use the bundled sample.
6. Select the retrieval engine and chunk settings.
7. Click **Build document index**.
8. Open **Ask documents**.
9. Enter a specific question.
10. Click **Search and answer**.
11. Review the generated answer.
12. Expand **View retrieved sources**.
13. Verify the filename, page number, relevance score, and evidence excerpt.
14. Export the conversation to Markdown when required.

## Retrieval modes

- **Auto:** attempts semantic retrieval first and falls back to TF-IDF.
- **Sentence Transformers:** multilingual meaning-based search.
- **TF-IDF:** lightweight keyword and phrase retrieval.

## Answer modes

### Extractive

Selects high-scoring sentences directly from the retrieved evidence.

- Does not require Ollama.
- Uses fewer computer resources.
- Produces answers close to the original text.
- Is easier to verify against the document.

### Ollama

Sends retrieved evidence to a local language model to generate a more natural response.

- Runs locally.
- Supports replaceable local models.
- Uses retrieved evidence as the answer context.
- Retains source citation labels such as `[S1]` and `[S2]`.

## Testing

```powershell
python -m unittest discover -s tests -v
```

Alternatively, double-click `run_tests.bat`.

The end-to-end test creates a PDF in memory and validates extraction, chunking, TF-IDF retrieval, answer generation, and the `[S1]` citation.

## Ollama timeout

The Ollama client uses separate connection and response timeouts:

```python
timeout=(10, read_timeout)
```

For slower CPU-only computers:

- Increase the read timeout.
- Use a smaller Ollama model.
- Reduce the number of evidence sources.
- Reduce the chunk size.
- Run the model once before using it in the application.

## Troubleshooting

### Python is not recognized

Reinstall Python and enable **Add Python to PATH**. Then verify the installation:

```powershell
python --version
```

### Virtual environment is missing

Run `setup_windows.bat`.

### The PDF contains no selectable text

The file may be an image-only scanned document. Convert it into a searchable PDF using OCR before uploading it.

### The semantic model cannot be loaded

Use **Auto** or **TF-IDF** retrieval.

### Ollama connection refused

Make sure Ollama is running:

```powershell
ollama serve
```

Check the port:

```powershell
Test-NetConnection localhost -Port 11434
```

### Ollama read timeout

Increase the timeout value, reduce the number of sources, or use a smaller model.

### Streamlit port is already in use

```powershell
streamlit run app.py --server.port 8502
```

## Limitations

- No OCR for image-only PDFs.
- The document index is stored in memory and rebuilt after restart.
- Chunking is based on words and pages rather than document headings.
- No cross-encoder reranker.
- No highlighted evidence inside a PDF viewer.
- Ollama responses are currently non-streaming.
- No authentication or multiuser support.
- No persistent vector database.

## Roadmap

- OCR support.
- Persistent vector storage.
- Cross-encoder reranking.
- Highlighted evidence inside a PDF viewer.
- Streaming local generation.
- Metadata filters.
- Retrieval evaluation dashboard.
- FastAPI backend layer.
- Authentication.
- Docker packaging.

## Technology stack

- Python
- Streamlit
- PyMuPDF
- Scikit-learn
- NumPy
- Sentence Transformers
- Requests
- Ollama

## Privacy

The application is designed to process documents locally. PDF content, extracted text, retrieval indexes, questions, answers, and evidence remain on the user's computer while the application is running.

Do not expose Streamlit to a public network without authentication, and verify retrieved evidence before using answers for important decisions.

## Documentation

Additional architecture notes are available in `docs/ARCHITECTURE.md`.

## License

This project is provided as portfolio and educational software. Add an appropriate license before redistributing or using the application commercially.
