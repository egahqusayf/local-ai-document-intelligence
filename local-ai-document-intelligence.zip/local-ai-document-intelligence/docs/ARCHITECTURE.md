# Architecture

```text
PDF files
   |
   v
PyMuPDF page extraction
   |
   v
Page-aware overlapping chunks
   |
   +-------------------------+
   |                         |
   v                         v
Sentence Transformer      TF-IDF fallback
   |                         |
   +------------+------------+
                |
                v
        Top-k evidence chunks
                |
        +-------+--------+
        |                |
        v                v
 Extractive answer   Ollama local LLM
        |                |
        +-------+--------+
                |
                v
Answer + page citations + source viewer + export
```

## Design decisions

- Each chunk belongs to exactly one page, which keeps citations unambiguous.
- Semantic retrieval is optional because the model download can be large.
- TF-IDF makes the project immediately usable on a modest Windows laptop.
- Ollama is isolated behind an HTTP client, so it can be replaced by another model provider.
- The UI and core logic are separated to make testing easier.
