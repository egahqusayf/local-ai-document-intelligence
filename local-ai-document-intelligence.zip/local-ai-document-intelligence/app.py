from __future__ import annotations

from pathlib import Path
import html

import streamlit as st

from src.answer_engine import answer_question
from src.exporter import answers_to_markdown
from src.pdf_processor import chunk_pages, extract_pages_from_bytes
from src.retriever import build_retriever


APP_DIR = Path(__file__).resolve().parent
SAMPLE_PDF = APP_DIR / "sample_docs" / "sample_ai_governance.pdf"

st.set_page_config(
    page_title="Local AI Document Intelligence",
    page_icon="📚",
    layout="wide",
)

PALETTES = {
    "light": {
        "primary": "#A11B27",
        "primary_soft": "rgba(161, 27, 39, 0.10)",
        "primary_soft_2": "rgba(161, 27, 39, 0.04)",
        "background": "#FFF9F9",
        "card": "#FFFFFF",
        "card_alt": "#FFF1F2",
        "border": "#E9CDD1",
        "text": "#3A0E13",
        "muted": "#7A4A50",
        "shadow": "0 10px 25px rgba(161, 27, 39, 0.08)",
    },
    "dark": {
        "primary": "#D94855",
        "primary_soft": "rgba(217, 72, 85, 0.16)",
        "primary_soft_2": "rgba(217, 72, 85, 0.07)",
        "background": "#14080B",
        "card": "#211014",
        "card_alt": "#2A141A",
        "border": "#553039",
        "text": "#FFF6F7",
        "muted": "#E8C7CB",
        "shadow": "0 10px 28px rgba(0, 0, 0, 0.24)",
    },
}


def current_palette() -> dict[str, str]:
    base = (st.get_option("theme.base") or "dark").lower()
    return PALETTES["light" if base == "light" else "dark"]


def inject_theme_css() -> None:
    p = current_palette()
    st.markdown(
        f"""
<style>
:root {{
  --accent: {p['primary']};
  --accent-soft: {p['primary_soft']};
  --accent-soft-2: {p['primary_soft_2']};
  --bg-soft: {p['background']};
  --card: {p['card']};
  --card-alt: {p['card_alt']};
  --border: {p['border']};
  --text: {p['text']};
  --muted: {p['muted']};
  --shadow: {p['shadow']};
}}

.block-container {{padding-top: 1.35rem; padding-bottom: 3rem;}}
.hero {{
  padding: 1.45rem 1.6rem;
  border: 1px solid var(--border);
  border-radius: 20px;
  background: linear-gradient(135deg, var(--accent-soft), var(--accent-soft-2));
  box-shadow: var(--shadow);
  margin-bottom: 1.1rem;
}}
.hero h1 {{margin: 0 0 .35rem 0; font-size: 2.05rem; color: var(--text);}}
.hero p {{margin: 0; color: var(--muted);}}
.metric-card {{
  border: 1px solid var(--border);
  background: var(--card);
  border-radius: 16px;
  padding: .9rem 1rem;
  min-height: 88px;
  box-shadow: var(--shadow);
}}
.metric-card h3 {{margin: .18rem 0 0 0; color: var(--text);}}
.source-card {{
  border-left: 4px solid var(--accent);
  border: 1px solid var(--border);
  background: var(--card-alt);
  border-radius: 12px;
  padding: .8rem 1rem;
  margin: .6rem 0;
  box-shadow: var(--shadow);
  color: var(--text);
}}
.small-muted {{color: var(--muted); font-size: .88rem;}}
.palette-chip-wrap {{display: flex; gap: .55rem; flex-wrap: wrap; margin-top: .7rem;}}
.palette-chip {{
  display: inline-flex; align-items: center; gap: .5rem;
  border: 1px solid var(--border); background: var(--card);
  border-radius: 999px; padding: .38rem .7rem; box-shadow: var(--shadow);
  color: var(--text); font-size: .86rem;
}}
.palette-dot {{width: 14px; height: 14px; border-radius: 50%; display:inline-block; border:1px solid rgba(0,0,0,.08);}}
div[data-testid="stDownloadButton"] > button,
button[kind="primary"] {{border-radius: 12px !important;}}
</style>
""",
        unsafe_allow_html=True,
    )


def init_state() -> None:
    defaults = {
        "retriever": None,
        "retriever_name": None,
        "pages": [],
        "chunks": [],
        "documents": [],
        "answers": [],
        "notice": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def clear_index() -> None:
    for key in ["retriever", "retriever_name", "pages", "chunks", "documents", "notice"]:
        st.session_state[key] = None if key in {"retriever", "retriever_name", "notice"} else []
    st.session_state.answers = []


init_state()
inject_theme_css()
palette = current_palette()
theme_name = (st.get_option("theme.base") or "dark").capitalize()

st.markdown(
    f"""
<div class="hero">
  <h1>Local AI Document Intelligence</h1>
  <p>Ask questions across multiple PDFs, retrieve evidence, and receive page-level citations. Runs locally on Windows.</p>
  <div class="palette-chip-wrap">
    <span class="palette-chip"><span class="palette-dot" style="background:{palette['primary']}"></span> Mendeley-inspired {theme_name} theme</span>
    <span class="palette-chip"><span class="palette-dot" style="background:{palette['background']}"></span> Background</span>
    <span class="palette-chip"><span class="palette-dot" style="background:{palette['card_alt']}"></span> Surfaces</span>
    <span class="palette-chip"><span class="palette-dot" style="background:{palette['text']}"></span> Text</span>
  </div>
</div>
""",
    unsafe_allow_html=True,
)

with st.sidebar:
    st.header("Configuration")
    st.caption("Color palette only follows the provided Mendeley reference. The app does not reuse the logo or symbol.")
    retrieval_engine = st.selectbox(
        "Retrieval engine",
        ["Auto", "Sentence Transformers", "TF-IDF"],
        help="Auto prefers multilingual semantic embeddings and falls back to TF-IDF.",
    )
    chunk_size = st.slider("Chunk size (words)", 100, 450, 220, 20)
    chunk_overlap = st.slider("Chunk overlap", 0, 80, 45, 5)
    top_k = st.slider("Sources per answer", 2, 10, 5)

    st.divider()
    answer_mode = st.radio("Answer mode", ["Extractive", "Ollama"], horizontal=True)
    ollama_model = st.text_input("Ollama model", value="llama3.2:3b")
    ollama_url = st.text_input("Ollama URL", value="http://localhost:11434")
    ollama_read_timeout = st.number_input(
        "Ollama read timeout (seconds)",
        min_value=30,
        max_value=1800,
        value=600,
        step=30,
        help="Maximum waiting time for one complete Ollama response. Use 300-600 seconds on CPU-only computers.",
    )
    st.caption("Ollama is optional. Extractive mode works without a local LLM.")

    st.divider()
    if st.button("Reset application", use_container_width=True):
        clear_index()
        st.rerun()

upload_tab, chat_tab, about_tab = st.tabs(["1. Index documents", "2. Ask documents", "Project info"])

with upload_tab:
    st.subheader("Add PDF documents")
    uploaded_files = st.file_uploader(
        "Choose one or more text-based PDFs",
        type=["pdf"],
        accept_multiple_files=True,
    )
    use_sample = st.checkbox(
        "Include the bundled sample document",
        value=not uploaded_files,
        help="Useful for testing the project immediately.",
    )

    left, right = st.columns([1, 3])
    with left:
        process_clicked = st.button("Build document index", type="primary", use_container_width=True)
    with right:
        st.caption(
            "Scanned PDFs are not OCR-processed in this MVP. Use PDFs that contain selectable text."
        )

    if process_clicked:
        file_items: list[tuple[str, bytes]] = []
        for file in uploaded_files or []:
            file_items.append((file.name, file.getvalue()))
        if use_sample and SAMPLE_PDF.exists():
            file_items.append((SAMPLE_PDF.name, SAMPLE_PDF.read_bytes()))

        if not file_items:
            st.warning("Add at least one PDF or enable the sample document.")
        else:
            pages = []
            errors = []
            with st.status("Reading and indexing documents...", expanded=True) as status:
                for filename, data in file_items:
                    st.write(f"Extracting: **{filename}**")
                    try:
                        pages.extend(extract_pages_from_bytes(data, filename))
                    except ValueError as exc:
                        errors.append(str(exc))
                if not pages:
                    status.update(label="Indexing failed", state="error")
                else:
                    st.write("Creating searchable chunks")
                    chunks = chunk_pages(pages, chunk_size=chunk_size, overlap=chunk_overlap)
                    st.write(f"Building {retrieval_engine} index")
                    try:
                        retriever, notice = build_retriever(chunks, retrieval_engine)
                    except Exception as exc:
                        status.update(label="Indexing failed", state="error")
                        st.error(str(exc))
                    else:
                        st.session_state.pages = pages
                        st.session_state.chunks = chunks
                        st.session_state.retriever = retriever
                        st.session_state.retriever_name = retriever.name
                        st.session_state.documents = sorted({page.filename for page in pages})
                        st.session_state.notice = notice
                        st.session_state.answers = []
                        status.update(label="Document index is ready", state="complete")

            for error in errors:
                st.warning(error)

    if st.session_state.retriever is not None:
        if st.session_state.notice:
            st.info(st.session_state.notice)
        cols = st.columns(4)
        metrics = [
            ("Documents", len(st.session_state.documents)),
            ("Text pages", len(st.session_state.pages)),
            ("Chunks", len(st.session_state.chunks)),
            ("Index", st.session_state.retriever_name),
        ]
        for col, (label, value) in zip(cols, metrics):
            with col:
                st.markdown(
                    f'<div class="metric-card"><div class="small-muted">{label}</div><h3>{value}</h3></div>',
                    unsafe_allow_html=True,
                )
        st.success("Index ready. Open the 'Ask documents' tab.")
        st.write("**Indexed files:** " + ", ".join(st.session_state.documents))

with chat_tab:
    if st.session_state.retriever is None:
        st.info("Build a document index in the first tab before asking questions.")
    else:
        st.subheader("Ask a grounded question")
        question = st.text_area(
            "Question",
            placeholder="Example: What risks and safeguards are discussed in the document?",
            height=95,
        )
        ask_clicked = st.button("Search and answer", type="primary")

        if ask_clicked:
            if not question.strip():
                st.warning("Enter a question first.")
            else:
                with st.spinner("Retrieving evidence and preparing the answer..."):
                    results = st.session_state.retriever.search(question, top_k=top_k)
                    try:
                        answer = answer_question(
                            question,
                            results,
                            mode=answer_mode,
                            ollama_model=ollama_model,
                            ollama_base_url=ollama_url,
                            ollama_read_timeout=int(ollama_read_timeout),
                        )
                    except Exception as exc:
                        st.error(f"{exc}")
                        st.info("Switch to Extractive mode or verify that Ollama is running.")
                    else:
                        st.session_state.answers.append(answer)

        if st.session_state.answers:
            st.divider()
            for answer_index, answer in enumerate(reversed(st.session_state.answers), start=1):
                with st.chat_message("user"):
                    st.write(answer.question)
                with st.chat_message("assistant"):
                    st.markdown(answer.text)
                    st.caption(f"Answer mode: {answer.mode}")
                    with st.expander("View retrieved sources"):
                        if not answer.sources:
                            st.write("No matching sources.")
                        for source_index, result in enumerate(answer.sources, start=1):
                            st.markdown(
                                f"""
<div class="source-card">
  <strong>S{source_index} - {html.escape(result.chunk.filename)}, page {result.chunk.page_number}</strong><br>
  <span class="small-muted">Relevance score: {result.score:.3f}</span><br><br>
  {html.escape(result.chunk.text[:1000])}
</div>
""",
                                unsafe_allow_html=True,
                            )

            export_text = answers_to_markdown(st.session_state.answers)
            st.download_button(
                "Download conversation (.md)",
                data=export_text,
                file_name="document_intelligence_conversation.md",
                mime="text/markdown",
            )

with about_tab:
    st.subheader("What this project demonstrates")
    st.markdown(
        """
- Multi-document PDF ingestion and page-aware text extraction.
- Overlapping document chunking for information retrieval.
- Multilingual semantic retrieval with a TF-IDF fallback.
- Grounded answer generation with source labels and page citations.
- Optional private local LLM integration through Ollama.
- Conversation history and Markdown export.
- Modular Python architecture suitable for extension into a full RAG system.
- Mendeley-inspired color palette in both light and dark versions, without copying the original logo or shape.

**Recommended portfolio demo:** compare the same question in TF-IDF, semantic retrieval, and Ollama modes, then explain how retrieval quality affects the final answer.
"""
    )
