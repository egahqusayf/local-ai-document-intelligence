"""Core package for Local AI Document Intelligence."""
