from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Sequence

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .models import Chunk, SearchResult


class BaseRetriever(ABC):
    name: str

    @abstractmethod
    def search(self, query: str, top_k: int = 5) -> list[SearchResult]:
        raise NotImplementedError


class TfidfRetriever(BaseRetriever):
    name = "TF-IDF"

    def __init__(self, chunks: Sequence[Chunk]):
        if not chunks:
            raise ValueError("At least one chunk is required to build the index.")
        self.chunks = list(chunks)
        self.vectorizer = TfidfVectorizer(
            lowercase=True,
            ngram_range=(1, 2),
            max_features=50_000,
            sublinear_tf=True,
            strip_accents="unicode",
        )
        self.matrix = self.vectorizer.fit_transform(chunk.text for chunk in self.chunks)

    def search(self, query: str, top_k: int = 5) -> list[SearchResult]:
        query = query.strip()
        if not query:
            return []
        query_vector = self.vectorizer.transform([query])
        scores = cosine_similarity(query_vector, self.matrix).ravel()
        top_k = max(1, min(top_k, len(self.chunks)))
        indices = np.argsort(scores)[::-1][:top_k]
        return [
            SearchResult(chunk=self.chunks[int(i)], score=float(scores[int(i)]))
            for i in indices
            if scores[int(i)] > 0
        ]


class SentenceTransformerRetriever(BaseRetriever):
    name = "Sentence Transformers"

    def __init__(
        self,
        chunks: Sequence[Chunk],
        model_name: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
    ):
        if not chunks:
            raise ValueError("At least one chunk is required to build the index.")
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise RuntimeError(
                "sentence-transformers is not installed. Install requirements.txt "
                "or use the TF-IDF engine."
            ) from exc

        self.chunks = list(chunks)
        self.model = SentenceTransformer(model_name)
        self.embeddings = self.model.encode(
            [chunk.text for chunk in self.chunks],
            normalize_embeddings=True,
            show_progress_bar=False,
        )

    def search(self, query: str, top_k: int = 5) -> list[SearchResult]:
        query = query.strip()
        if not query:
            return []
        query_embedding = self.model.encode(
            [query], normalize_embeddings=True, show_progress_bar=False
        )[0]
        scores = np.asarray(self.embeddings) @ np.asarray(query_embedding)
        top_k = max(1, min(top_k, len(self.chunks)))
        indices = np.argsort(scores)[::-1][:top_k]
        return [
            SearchResult(chunk=self.chunks[int(i)], score=float(scores[int(i)]))
            for i in indices
        ]


def build_retriever(
    chunks: Sequence[Chunk],
    engine: str = "auto",
    model_name: str = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
) -> tuple[BaseRetriever, str | None]:
    """Build the selected retriever and return an optional fallback notice."""
    normalized = engine.strip().lower()
    if normalized in {"tf-idf", "tfidf"}:
        return TfidfRetriever(chunks), None

    if normalized in {"sentence transformers", "sentence-transformers", "semantic"}:
        return SentenceTransformerRetriever(chunks, model_name=model_name), None

    if normalized != "auto":
        raise ValueError(f"Unknown retrieval engine: {engine}")

    try:
        return SentenceTransformerRetriever(chunks, model_name=model_name), None
    except Exception as exc:
        notice = (
            "Semantic model could not be loaded, so the app used TF-IDF instead. "
            f"Reason: {exc}"
        )
        return TfidfRetriever(chunks), notice
