from __future__ import annotations

import requests


class OllamaError(RuntimeError):
    pass


class OllamaClient:
    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        connect_timeout: int = 10,
        read_timeout: int = 600,
    ):
        self.base_url = base_url.rstrip("/")
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout

    @property
    def request_timeout(self) -> tuple[int, int]:
        """Return (connect timeout, read timeout) for requests."""
        return self.connect_timeout, self.read_timeout

    def list_models(self) -> list[str]:
        try:
            response = requests.get(
                f"{self.base_url}/api/tags",
                timeout=(self.connect_timeout, 15),
            )
            response.raise_for_status()
            return [item["name"] for item in response.json().get("models", [])]
        except requests.RequestException as exc:
            raise OllamaError(
                f"Cannot connect to Ollama at {self.base_url}: {exc}"
            ) from exc

    def generate(self, model: str, prompt: str, temperature: float = 0.1) -> str:
        payload = {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "options": {"temperature": temperature},
        }
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json=payload,
                timeout=self.request_timeout,
            )
            response.raise_for_status()
        except requests.exceptions.ReadTimeout as exc:
            raise OllamaError(
                "Ollama exceeded the configured read timeout "
                f"({self.read_timeout} seconds). Increase 'Ollama read timeout' "
                "in the sidebar, reduce the number of retrieved sources, or use a smaller model."
            ) from exc
        except requests.exceptions.ConnectTimeout as exc:
            raise OllamaError(
                f"Connection to Ollama exceeded {self.connect_timeout} seconds. "
                "Verify that Ollama is running at the configured URL."
            ) from exc
        except requests.RequestException as exc:
            raise OllamaError(f"Ollama generation failed: {exc}") from exc

        text = response.json().get("response", "").strip()
        if not text:
            raise OllamaError("Ollama returned an empty response.")
        return text
