from __future__ import annotations

import re
from collections import Counter

from .models import Answer, SearchResult
from .ollama_client import OllamaClient


_SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")
_TOKEN_RE = re.compile(r"[A-Za-zÀ-ÿ0-9_\-]+", re.UNICODE)


def _tokens(text: str) -> list[str]:
    return [token.lower() for token in _TOKEN_RE.findall(text) if len(token) > 2]


def format_source_label(index: int, result: SearchResult) -> str:
    return f"[S{index}] {result.chunk.filename}, page {result.chunk.page_number}"


def build_context(results: list[SearchResult]) -> str:
    sections = []
    for index, result in enumerate(results, start=1):
        sections.append(
            f"SOURCE S{index}\n"
            f"File: {result.chunk.filename}\n"
            f"Page: {result.chunk.page_number}\n"
            f"Relevance: {result.score:.3f}\n"
            f"Text: {result.chunk.text}"
        )
    return "\n\n".join(sections)


def extractive_answer(question: str, results: list[SearchResult], max_sentences: int = 5) -> str:
    if not results:
        return (
            "I could not find a relevant passage in the indexed documents. "
            "Try a more specific question or add another document."
        )

    query_terms = Counter(_tokens(question))
    candidates: list[tuple[float, str, int]] = []

    for source_index, result in enumerate(results, start=1):
        sentences = _SENTENCE_SPLIT_RE.split(result.chunk.text)
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) < 35:
                continue
            sentence_terms = Counter(_tokens(sentence))
            overlap = sum(
                min(query_terms[term], sentence_terms[term]) for term in query_terms
            )
            lexical_score = overlap / max(1, sum(query_terms.values()))
            length_bonus = min(len(sentence) / 400, 0.25)
            score = (0.65 * result.score) + (0.30 * lexical_score) + (0.05 * length_bonus)
            candidates.append((score, sentence, source_index))

    if not candidates:
        first = results[0]
        excerpt = first.chunk.text[:650].strip()
        return f"{excerpt} [S1]"

    candidates.sort(key=lambda item: item[0], reverse=True)
    selected: list[tuple[str, int]] = []
    seen = set()
    for _, sentence, source_index in candidates:
        key = sentence.lower()[:120]
        if key in seen:
            continue
        seen.add(key)
        selected.append((sentence, source_index))
        if len(selected) >= max_sentences:
            break

    paragraphs = [f"{sentence} [S{source_index}]" for sentence, source_index in selected]
    return "\n\n".join(paragraphs)


def ollama_answer(
    question: str,
    results: list[SearchResult],
    model: str,
    base_url: str,
    read_timeout: int = 600,
) -> str:
    if not results:
        return extractive_answer(question, results)

    prompt = f"""You are a document-grounded assistant.
Answer the user's question using ONLY the provided sources.

Rules:
1. Do not invent facts that are absent from the sources.
2. Cite claims using [S1], [S2], and so on.
3. If the sources are insufficient, state that clearly.
4. Answer in the same language as the user's question.
5. Prefer a concise answer with a short conclusion.

USER QUESTION:
{question}

SOURCES:
{build_context(results)}

ANSWER:
"""
    client = OllamaClient(base_url=base_url, read_timeout=read_timeout)
    return client.generate(model=model, prompt=prompt)


def answer_question(
    question: str,
    results: list[SearchResult],
    mode: str = "Extractive",
    ollama_model: str = "llama3.2:3b",
    ollama_base_url: str = "http://localhost:11434",
    ollama_read_timeout: int = 600,
) -> Answer:
    normalized_mode = mode.strip().lower()
    if normalized_mode == "ollama":
        text = ollama_answer(
            question,
            results,
            ollama_model,
            ollama_base_url,
            read_timeout=ollama_read_timeout,
        )
        used_mode = f"Ollama ({ollama_model})"
    else:
        text = extractive_answer(question, results)
        used_mode = "Extractive"
    return Answer(question=question, text=text, sources=results, mode=used_mode)
