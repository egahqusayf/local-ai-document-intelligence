from __future__ import annotations

from datetime import datetime

from .models import Answer


def answers_to_markdown(answers: list[Answer], project_name: str = "Document Intelligence") -> str:
    lines = [
        f"# {project_name} - Conversation Export",
        "",
        f"Exported: {datetime.now().astimezone().isoformat(timespec='seconds')}",
        "",
    ]
    for index, answer in enumerate(answers, start=1):
        lines.extend(
            [
                f"## Question {index}",
                "",
                answer.question,
                "",
                f"**Answer mode:** {answer.mode}",
                "",
                answer.text,
                "",
                "### Sources",
                "",
            ]
        )
        if not answer.sources:
            lines.append("- No source matched.")
        else:
            for source_index, result in enumerate(answer.sources, start=1):
                excerpt = result.chunk.text.replace("\n", " ")[:300]
                lines.append(
                    f"- S{source_index}: `{result.chunk.filename}`, page "
                    f"{result.chunk.page_number}, score {result.score:.3f} - {excerpt}..."
                )
        lines.extend(["", "---", ""])
    return "\n".join(lines)
