from __future__ import annotations

import hashlib
import io
import re
from pathlib import Path
from typing import Iterable

import fitz  # PyMuPDF

from .models import Chunk, DocumentPage


_WHITESPACE_RE = re.compile(r"[\t\r\f\v ]+")
_MULTI_NEWLINE_RE = re.compile(r"\n{3,}")


def normalize_text(text: str) -> str:
    """Normalize PDF text while preserving useful paragraph boundaries."""
    text = text.replace("\u00ad", "")
    text = text.replace("\u00a0", " ")
    text = _WHITESPACE_RE.sub(" ", text)
    text = re.sub(r" *\n *", "\n", text)
    text = _MULTI_NEWLINE_RE.sub("\n\n", text)
    return text.strip()


def file_digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()[:16]


def extract_pages_from_bytes(data: bytes, filename: str) -> list[DocumentPage]:
    """Extract text from each page of a PDF byte stream."""
    if not data:
        raise ValueError(f"File '{filename}' is empty.")

    doc_id = file_digest(data)
    try:
        document = fitz.open(stream=io.BytesIO(data), filetype="pdf")
    except Exception as exc:  # pragma: no cover - depends on damaged input
        raise ValueError(f"Unable to open '{filename}' as a PDF: {exc}") from exc

    pages: list[DocumentPage] = []
    try:
        if document.page_count == 0:
            raise ValueError(f"PDF '{filename}' contains no pages.")
        for page_index in range(document.page_count):
            page = document.load_page(page_index)
            text = normalize_text(page.get_text("text"))
            if text:
                pages.append(
                    DocumentPage(
                        doc_id=doc_id,
                        filename=filename,
                        page_number=page_index + 1,
                        text=text,
                    )
                )
    finally:
        document.close()

    if not pages:
        raise ValueError(
            f"No selectable text was found in '{filename}'. "
            "The PDF may be scanned and require OCR."
        )
    return pages


def extract_pages_from_path(path: str | Path) -> list[DocumentPage]:
    file_path = Path(path)
    return extract_pages_from_bytes(file_path.read_bytes(), file_path.name)


def chunk_pages(
    pages: Iterable[DocumentPage],
    chunk_size: int = 220,
    overlap: int = 45,
) -> list[Chunk]:
    """Split pages into overlapping word chunks while preserving page citations."""
    if chunk_size < 50:
        raise ValueError("chunk_size must be at least 50 words.")
    if overlap < 0 or overlap >= chunk_size:
        raise ValueError("overlap must be >= 0 and smaller than chunk_size.")

    chunks: list[Chunk] = []
    step = chunk_size - overlap

    for page in pages:
        words = page.text.split()
        if not words:
            continue
        for start in range(0, len(words), step):
            end = min(start + chunk_size, len(words))
            chunk_text = " ".join(words[start:end]).strip()
            if len(chunk_text) < 40:
                continue
            chunk_id = f"{page.doc_id}-p{page.page_number}-w{start}"
            chunks.append(
                Chunk(
                    chunk_id=chunk_id,
                    doc_id=page.doc_id,
                    filename=page.filename,
                    page_number=page.page_number,
                    text=chunk_text,
                    word_start=start,
                    word_end=end,
                )
            )
            if end == len(words):
                break

    if not chunks:
        raise ValueError("No searchable chunks could be created from the documents.")
    return chunks
