from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass(frozen=True)
class DocumentPage:
    doc_id: str
    filename: str
    page_number: int
    text: str


@dataclass(frozen=True)
class Chunk:
    chunk_id: str
    doc_id: str
    filename: str
    page_number: int
    text: str
    word_start: int
    word_end: int


@dataclass(frozen=True)
class SearchResult:
    chunk: Chunk
    score: float


@dataclass
class Answer:
    question: str
    text: str
    sources: list[SearchResult]
    mode: str
    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(timespec="seconds")
    )
