from __future__ import annotations

import sys
import unittest
from pathlib import Path

import fitz

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from src.answer_engine import answer_question
from src.pdf_processor import chunk_pages, extract_pages_from_bytes
from src.retriever import TfidfRetriever


class CorePipelineTest(unittest.TestCase):
    @staticmethod
    def make_pdf() -> bytes:
        doc = fitz.open()
        page = doc.new_page()
        page.insert_text(
            (72, 72),
            "Predictive maintenance uses sensor data to identify abnormal machine behavior. "
            "Temperature and vibration trends can indicate an impending failure. "
            "A monitoring dashboard should display alerts and maintenance recommendations.",
            fontsize=11,
        )
        data = doc.tobytes()
        doc.close()
        return data

    def test_end_to_end_pipeline(self) -> None:
        pages = extract_pages_from_bytes(self.make_pdf(), "test.pdf")
        self.assertEqual(len(pages), 1)
        chunks = chunk_pages(pages, chunk_size=60, overlap=10)
        self.assertGreaterEqual(len(chunks), 1)
        retriever = TfidfRetriever(chunks)
        results = retriever.search("What indicates machine failure?", top_k=3)
        self.assertGreaterEqual(len(results), 1)
        answer = answer_question("What indicates machine failure?", results)
        self.assertIn("[S1]", answer.text)
        self.assertEqual(answer.sources[0].chunk.page_number, 1)

    def test_empty_query(self) -> None:
        pages = extract_pages_from_bytes(self.make_pdf(), "test.pdf")
        retriever = TfidfRetriever(chunk_pages(pages, chunk_size=60, overlap=10))
        self.assertEqual(retriever.search("   "), [])


if __name__ == "__main__":
    unittest.main()
