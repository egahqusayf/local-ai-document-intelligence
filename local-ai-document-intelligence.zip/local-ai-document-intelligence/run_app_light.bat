@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. Run setup_windows.bat first.
  pause
  exit /b 1
)
call .venv\Scripts\python.exe -m streamlit run app.py --theme.base light --theme.primaryColor "#A11B27" --theme.backgroundColor "#FFF9F9" --theme.secondaryBackgroundColor "#FFF1F2" --theme.textColor "#3A0E13"
