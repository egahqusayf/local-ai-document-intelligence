@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. Run setup_windows.bat first.
  pause
  exit /b 1
)
call .venv\Scripts\python.exe -m streamlit run app.py --theme.base dark --theme.primaryColor "#D94855" --theme.backgroundColor "#14080B" --theme.secondaryBackgroundColor "#211014" --theme.textColor "#FFF6F7"
